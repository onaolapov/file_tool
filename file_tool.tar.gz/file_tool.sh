#!/bin/bash

# # File Manipulation CLI Tool with User Input
# # Usage: ./file_tool.sh or follow interactive prompts

# set -e

# usage() {
#     echo "Usage: $0 {create|copy|combine|delete} [arguments]"
#     echo "Interactive Mode: Run the script without arguments to follow prompts."
#     exit 1
# }

# prompt_create_file() {
#     read -p "Enter filename to create: " file
#     read -p "Enter text to add to the file (optional): " text
#     echo "$text" > "$file"
#     echo "File '$file' created with content: '$text'"
# }

# prompt_copy_file() {
#     read -p "Enter the source file to copy: " src
#     if [ ! -f "$src" ]; then
#         echo "Source file does not exist!"
#         exit 1
#     fi
#     read -p "Enter the destination file: " dest
#     cp "$src" "$dest"
#     echo "File '$src' copied to '$dest'."
# }

# prompt_combine_files() {
#     read -p "Enter the first file to combine: " file1
#     read -p "Enter the second file to combine: " file2
#     if [ ! -f "$file1" ] || [ ! -f "$file2" ]; then
#         echo "One or both files do not exist!"
#         exit 1
#     fi
#     read -p "Enter the output file name: " output
#     cat "$file1" "$file2" > "$output"
#     echo "Files '$file1' and '$file2' combined into '$output'."
# }

# prompt_delete_file() {
#     read -p "Enter filename to delete: " file
#     if [ ! -f "$file" ]; then
#         echo "File '$file' does not exist!"
#         exit 1
#     fi
#     read -p "Are you sure you want to delete '$file'? (y/n): " confirm
#     if [ "$confirm" = "y" ]; then
#         rm "$file"
#         echo "File '$file' deleted."
#     else
#         echo "Delete operation canceled."
#     fi
# }

# main_interactive() {
#     echo "Welcome to the File Manipulation CLI Tool!"
#     echo "Available Commands: create, copy, combine, delete, exit"
#     while true; do
#         echo
#         read -p "Enter a command: " command
#         case "$command" in
#             create) prompt_create_file ;;
#             copy) prompt_copy_file ;;
#             combine) prompt_combine_files ;;
#             delete) prompt_delete_file ;;
#             exit) echo "Exiting tool. Goodbye!"; exit 0 ;;
#             *) echo "Invalid command. Try again." ;;
#         esac
#     done
# }

# # Script starts here
# if [ $# -eq 0 ]; then
#     main_interactive
# else
#     command="$1"
#     shift
#     case "$command" in
#         create) prompt_create_file ;;
#         copy) prompt_copy_file ;;
#         combine) prompt_combine_files ;;
#         delete) prompt_delete_file ;;
#         *) usage ;;
#     esac
# fi

#!/bin/bash

# File Manipulation CLI Tool with User Input and Command Support
# Usage: ./file_tool.sh <command> [arguments]

#!/usr/bin/env bash

# File Manipulation CLI Tool
set -e

usage() {
    echo "Usage: $0 {create|copy|combine|delete} [arguments]"
    echo "Interactive Mode: Run the script without arguments."
    exit 1
}

create_file() {
    local file="$1"
    local text="$2"
    echo "$text" > "$file"
    echo "File '$file' created with content: '$text'."
}

copy_file() {
    local src="$1"
    local dest="$2"
    cp "$src" "$dest"
    echo "File '$src' copied to '$dest'."
}

combine_files() {
    local file1="$1"
    local file2="$2"
    local output="$3"
    cat "$file1" "$file2" > "$output"
    echo "Files '$file1' and '$file2' combined into '$output'."
}

delete_file() {
    local file="$1"
    rm -f "$file"
    echo "File '$file' deleted."
}

interactive_mode() {
    while true; do
        echo "Commands: create, copy, combine, delete, exit"
        read -p "Enter a command: " cmd
        case "$cmd" in
            create) read -p "Filename: " file; read -p "Text: " text; create_file "$file" "$text" ;;
            copy) read -p "Source file: " src; read -p "Destination file: " dest; copy_file "$src" "$dest" ;;
            combine) read -p "First file: " f1; read -p "Second file: " f2; read -p "Output file: " out; combine_files "$f1" "$f2" "$out" ;;
            delete) read -p "File to delete: " file; delete_file "$file" ;;
            exit) exit 0 ;;
            *) echo "Invalid command." ;;
        esac
    done
}

if [ $# -eq 0 ]; then
    interactive_mode
else
    case "$1" in
        create) create_file "$2" "$3" ;;
        copy) copy_file "$2" "$3" ;;
        combine) combine_files "$2" "$3" "$4" ;;
        delete) delete_file "$2" ;;
        *) usage ;;
    esac
fi
