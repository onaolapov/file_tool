# Test Configuration Variables
TEST_FILE1="testfile1.txt"
TEST_FILE2="testfile2.txt"
COPY_FILE="copyfile.txt"
COMBINED_FILE="combined_file.txt"

TEST_CONTENT1="Content for Test File 1"
TEST_CONTENT2="Content for Test File 2"
