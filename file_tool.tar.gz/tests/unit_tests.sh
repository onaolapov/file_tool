# #!/bin/bash
# set -e

# # Source test configuration
# source "$(dirname "$0")/test_config.sh"

# # Locate file_tool.sh dynamically
# SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd .. && pwd)"
# FILE_TOOL="$SCRIPT_DIR/file_tool.sh"

# if [ ! -f "$FILE_TOOL" ]; then
#     echo "Error: file_tool.sh not found in $SCRIPT_DIR"
#     exit 1
# fi

# echo "Running Unit Tests..."

# # Test: Create a file
# "$FILE_TOOL" create "$TEST_FILE1" "$TEST_CONTENT1"
# grep "$TEST_CONTENT1" "$TEST_FILE1" && echo "Create Test Passed"

# # Test: Copy the file
# "$FILE_TOOL" copy "$TEST_FILE1" "$COPY_FILE"
# [ -f "$COPY_FILE" ] && echo "Copy Test Passed"

# # Test: Combine two files
# "$FILE_TOOL" create "$TEST_FILE2" "$TEST_CONTENT2"
# "$FILE_TOOL" combine "$TEST_FILE1" "$TEST_FILE2" "$COMBINED_FILE"
# grep "$TEST_CONTENT1" "$COMBINED_FILE" && grep "$TEST_CONTENT2" "$COMBINED_FILE" && echo "Combine Test Passed"

# # Test: Delete files
# "$FILE_TOOL" delete "$TEST_FILE1"
# "$FILE_TOOL" delete "$TEST_FILE2"
# "$FILE_TOOL" delete "$COPY_FILE"
# "$FILE_TOOL" delete "$COMBINED_FILE"

# [ ! -f "$TEST_FILE1" ] && [ ! -f "$TEST_FILE2" ] && [ ! -f "$COPY_FILE" ] && [ ! -f "$COMBINED_FILE" ] && echo "Delete Test Passed"

# echo "All Unit Tests Passed!"
#!/usr/bin/env bash
set -e

# Source test configuration
CONFIG_FILE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/test_config.sh"
. "$CONFIG_FILE"

# Locate file_tool.sh
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && cd .. && pwd)"
FILE_TOOL="$SCRIPT_DIR/file_tool.sh"

echo "Running Unit Tests..."

# Test file creation
"$FILE_TOOL" create "$TEST_FILE1" "$TEST_CONTENT1"
grep "$TEST_CONTENT1" "$TEST_FILE1" && echo "Create Test Passed"

# Test file copy
"$FILE_TOOL" copy "$TEST_FILE1" "$COPY_FILE"
[ -f "$COPY_FILE" ] && echo "Copy Test Passed"

# Test file combine
"$FILE_TOOL" combine "$TEST_FILE1" "$COPY_FILE" "$COMBINED_FILE"
grep "$TEST_CONTENT1" "$COMBINED_FILE" && echo "Combine Test Passed"

# Test file deletion
"$FILE_TOOL" delete "$TEST_FILE1"
"$FILE_TOOL" delete "$COPY_FILE"
"$FILE_TOOL" delete "$COMBINED_FILE"
[ ! -f "$TEST_FILE1" ] && [ ! -f "$COPY_FILE" ] && [ ! -f "$COMBINED_FILE" ] && echo "Delete Test Passed"

echo "All Unit Tests Passed!"
